<?php

require_once( 'login_base.php' );

/**
 * Login tests - the regular way (submitting username & password)
 *
 * @group auth
 * @group login
 * @since 0.1
 */
class Auth_Login_Normal_Tests extends Login_Base {

}
