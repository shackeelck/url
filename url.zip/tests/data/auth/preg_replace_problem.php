<?php

/** Valid PHP syntax but too complicated for our parser */

$login = 'joe';
$password = 'some_password';
$yourls_user_passwords = [
    $login => $password,
];
