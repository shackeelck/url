<?php
/*
Plugin Name: regular
Plugin URI: regular
Description: regular
Version: regular
Author: regular
Author URI: regular
*/
