<?php
/**
 * Plugin Name: phpdoc
 * Plugin URI: phpdoc
 * Description: phpdoc
 * Version: phpdoc
 * Author: phpdoc
 * Author URI: phpdoc
 */
