<?php
/*
Plugin Name: Test Plugin
Plugin URI: https://github.com/YOURLS/YOURLS
Description: This plugin does nothing
Version: 1.0
Author: Ozh
Author URI: https://ozh.org/
*/

// This plugin does nothing. Its role is to be loaded by the unit tests and
// at the same time to not modify any YOURLS default behavior
